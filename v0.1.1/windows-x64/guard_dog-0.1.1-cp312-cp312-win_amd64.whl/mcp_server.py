"""
Guard Dog MCP Server

Exposes the guard_dog security scanner as MCP tools that can be called
by MCP clients like Claude Desktop, IDEs, or other AI pipelines.

Usage:
    python mcp_server.py
    
Or via the installed script:
    guard-dog-mcp
"""

from mcp.server.fastmcp import FastMCP
from guard_dog.scanner import scan

# Create MCP server
mcp = FastMCP(
    "guard-dog",
    instructions="Security scanner for detecting prompt injection, unicode attacks, and other LLM threats"
)


@mcp.tool()
def scan_text(text: str, user_id: str = None, conversation_id: str = None) -> dict:
    """
    Scan text for security threats including prompt injection, unicode obfuscation,
    system prompt extraction attempts, and more.
    
    Args:
        text: The text to scan for security threats
        user_id: Optional user identifier for logging/tracking
        conversation_id: Optional conversation identifier for logging/tracking
    
    Returns:
        A dictionary containing:
        - is_clean: Boolean indicating if text passed all checks
        - risk_score: Float from 0.0 to 1.0 indicating threat level
        - issues: List of detected security issues with descriptions
        - timestamp: When the scan was performed
    """
    # Build metadata from optional parameters
    metadata = {}
    if user_id:
        metadata["user_id"] = user_id
    if conversation_id:
        metadata["conversation_id"] = conversation_id
    
    # Run the scan
    result = scan(text, metadata if metadata else None)
    
    return result.to_dict()


@mcp.tool()
def get_detection_categories() -> dict:
    """
    Get a list of all security threat categories that guard_dog can detect.
    
    Returns:
        A dictionary with detection categories and their descriptions.
    """
    return {
        "categories": [
            {
                "name": "Unicode Obfuscation",
                "description": "Detects invisible characters, homoglyphs, bidi control characters, and mixed scripts",
                "mitre_atlas": None
            },
            {
                "name": "Prompt Injection",
                "description": "Detects jailbreak attempts, instruction override patterns, and role manipulation",
                "mitre_atlas": None
            },
            {
                "name": "System Prompt Extraction",
                "description": "Detects attempts to extract system prompts or initial instructions",
                "mitre_atlas": "AML.T0056"
            },
            {
                "name": "Resource Exhaustion",
                "description": "Detects token flooding and denial-of-service attempts",
                "mitre_atlas": "AML.T0029"
            },
            {
                "name": "Code Injection",
                "description": "Detects attempts to execute code, SQL injection, and dangerous function calls",
                "mitre_atlas": None
            },
            {
                "name": "Escape Character Abuse",
                "description": "Detects null bytes, excessive backslashes, and escape sequence attacks",
                "mitre_atlas": None
            }
        ]
    }


@mcp.tool()
def quick_check(text: str) -> dict:
    """
    Perform a quick security check and return a simple pass/fail result.
    Use this for fast validation when you just need to know if text is safe.
    
    Args:
        text: The text to check
        
    Returns:
        A dictionary with:
        - safe: Boolean - True if no threats detected
        - risk_level: String - "low", "medium", or "high"
        - summary: Brief description of findings
    """
    result = scan(text)
    
    # Determine risk level
    if result.risk_score < 0.3:
        risk_level = "low"
    elif result.risk_score < 0.7:
        risk_level = "medium"
    else:
        risk_level = "high"
    
    # Build summary
    if result.is_clean:
        summary = "No security threats detected."
    else:
        issue_types = list(set(issue.get('type', 'Unknown') for issue in result.issues))
        summary = f"Detected {len(result.issues)} issue(s): {', '.join(issue_types)}"
    
    return {
        "safe": result.is_clean,
        "risk_level": risk_level,
        "risk_score": result.risk_score,
        "summary": summary
    }


if __name__ == "__main__":
    # Run the server using stdio transport (standard for MCP)
    mcp.run()
