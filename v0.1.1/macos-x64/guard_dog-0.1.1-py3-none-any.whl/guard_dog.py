import importlib.util
from importlib.machinery import ExtensionFileLoader
from pathlib import Path
import sys

candidates = []
for entry in sys.path:
    try:
        p = Path(entry)
    except Exception:
        continue
    if not p.exists() or not p.is_dir():
        continue
    candidates.extend([c for c in p.glob("guard_dog*.pyd")])
    candidates.extend([c for c in p.glob("guard_dog*.so")])
parent = Path(__file__).resolve().parent
candidates.extend([c for c in parent.glob("guard_dog*.pyd")])
candidates.extend([c for c in parent.glob("guard_dog*.so")])
unique = sorted({c.resolve() for c in candidates}, reverse=True)
if not unique:
    raise ImportError("guard_dog compiled module not found")
path = str(unique[0])
loader = ExtensionFileLoader(__name__, path)
spec = importlib.util.spec_from_file_location(__name__, path, loader=loader)
module = importlib.util.module_from_spec(spec)
loader.exec_module(module)
globals().update(module.__dict__)
